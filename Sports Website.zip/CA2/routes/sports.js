var express = require("express");
var router = express.Router();
var MySql = require('sync-mysql');

router.get('/', function(req, res, next) {
  var connection = new MySql({
    host: 'localhost',
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague'
  });
  var staff = connection.query("SELECT * from sports");
  console.log(sports);
  res.render('sports', { title: 'Express', sports:sports });
});

router.get('/add', function(req, res, next){
  res.render('add_sports')
})


/*
Sport VARCHAR(50),
Country VARCHAR(30)
*/

router.post('/add', function(req, res, next) {
  var Sport = req.body.Sport
  var Country = req.body.Country
  var connection = new MySql({
    host: 'localhost',
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague'
  })
  connection.query("INSERT INTO sports (Sport, Country) VALUES ((?), (?));", [Sport, Country]);
  res.redirect("/sports");
})

router.get('/update', function(req, res, next){
  var sports_id = req.query.sports_id
  var error = req.query.error
  res.render('update_sports', {sports_id: sports_id, error:error} )
})

router.post('/update', function(req, res, next){
  var sports_id = req.body.sports_id
  var Sport = req.body.Sport
  var country = req.body.Country
  var connection = new MySql({
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague',
    host: 'Localhost'
  })
  var query_string = "UPDATE sports set"
  var params = []
  if(Sport) {
    query_string += ' Sport = (?)'
    params.push(Sport)
  }
  
  if(Country) {
    if(sport || Country) {
      query_string +=", "
    }
    query_string += ' Country = (?) '
    params.push(Country)
  }

  query_string += "WHERE sports_id = (?)"
  if(!Sport && !Country) {
    res.redirect(`/sports/update?sports_id=${sports_id}&error=You must update some fields`)
  }
  params.push(sports_id)
  connection.query(query_string, params)
  res.redirect('/sports')
})

module.exports = router;