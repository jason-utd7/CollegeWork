var express = require("express");
var router = express.Router();
var MySql = require('sync-mysql');

router.get('/', function(req, res, next) {
  var connection = new MySql({
    host: 'localhost',
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague'
  });
  var staff = connection.query("SELECT * from Team");
  console.log(Team);
  res.render('Team', { title: 'Express', Team:Team });
});

router.get('/add', function(req, res, next){
  res.render('add_Team')
})
/*
Team varchar(50), 
Sport varchar(30),
Origin varchar(30), 
League varchar(30)
*/

router.post('/add', function(req, res, next) {
  var Team = req.body.Team
  var Sport = req.body.Sport
  var Origin = parseFloat(req.body.salary)
  var League = req.body.League
  var connection = new MySql({
    host: 'localhost',
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague'
  })
  connection.query("INSERT INTO Team (Team, Sport, Origin, League) VALUES ((?), (?), (?), (?));", [name, address, salary, position]);
  res.redirect("/Team");
})

router.get('/update', function(req, res, next){
  var Team_id = req.query.Team_id
  var error = req.query.error
  res.render('update_Team', {Team_id: Team_id, error:error} )
})

router.post('/update', function(req, res, next){
  var Team_id = req.body.Team_id
  var Team = req.body.Team
  var Sport = req.body.Sport
  var Origin = req.body.Origin
  var League = req.body.League
  var connection = new MySql({
    user: 'root',
    password: 'Password12345',
    database: 'SuperLeague',
    host: 'localhost'
  })
  var query_string = "UPDATE Team set"
  var params = []
  if(Team) {
    query_string += ' Team = (?)'
    params.push(Team)
  }
  if(Sport){
      query_String += ' Sport = (?)'
      params.push(Sport)
  }
  if(Sport) {
    if(Team || Origin) {
      query_string +=", "
    }
    query_string += ' Origin = (?) '
    params.push(Origin)
  }
  if(League) {
    if(Team || Origin || Sport) {
      query_string +=", "
    }
    query_string += ' Sport = (?) '
    params.push(Sport)
  }
  query_string += "WHERE Team_id = (?)"
  if(!Team && !Origin && !League && !Sport) {
    res.redirect(`/Team/update?Team_id=${Team_id}&error=You must update some fields`)
  }
  params.push(Team_id)
  connection.query(query_string, params)
  res.redirect('/Team')
})

module.exports = router;
