/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TheGameLabApp;
import java.util.*;
/**
 *
 * @author jason
 */
public class GameApp {
    
    
    public static void main(String[] args){
        
        GameAppGUI guigameapp=new GameAppGUI();
        guigameapp.setVisible(true);
        
    }
}
